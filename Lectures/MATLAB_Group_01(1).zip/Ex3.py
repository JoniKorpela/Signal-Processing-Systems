import numpy as np
import matplotlib.pyplot as plt
from scipy import special as sp
from scipy.stats import norm

# qfunc was taken from link below
# https://stackoverflow.com/questions/49115700/python-equivalent-of-matlabs-qfuncinv
def qfunc(arg):
    return 0.5-0.5*sp.erf(arg/np.sqrt(2))

    # Task 2

def main():
    MC = int(10e5)
    N = 50
    A = 1
    noise_variance = 1
    C_10 = 2
    C_01 = 2

    prior_H0 = 0.5
    prior_H1 = 1 - prior_H0

    S = (np.ones((N)) / np.sqrt(N))
    threshold_bayes = A / (2 * np.sqrt(N))
    state_of_nature = np.zeros(MC)
    x_observed_all = np.zeros((N, MC))
    x_observed_means = np.zeros(MC)
    
    PFA_THEORY = qfunc(threshold_bayes / np.sqrt(noise_variance / N))
    PD_THEORY = qfunc((threshold_bayes - A*S[0]) / np.sqrt(noise_variance / N))
    PM_THEORY = 1 - PD_THEORY
    PE_THEORY = PM_THEORY * prior_H1 + PFA_THEORY * prior_H0
    BAYES_RISK_THEORY = C_01 * PM_THEORY * prior_H1 + C_10 * PFA_THEORY * prior_H0

    for Mc in range(0, MC):
        state_of_nature[Mc] = np.random.binomial(1, prior_H1)
        x = A * state_of_nature[Mc] * S + np.sqrt(noise_variance) * np.random.randn(N)
        x_observed_all[:, Mc] = x
        x_observed_means[Mc] = np.mean(x)

    PFA_SIMULATED = np.mean(x_observed_means[state_of_nature == 0] > threshold_bayes)
    PD_SIMULATED = np.mean(x_observed_means[state_of_nature == 1] > threshold_bayes)

    PM_SIMULATED = 1 - PD_SIMULATED
    PE_SIMULATED = (np.sum((x_observed_means[state_of_nature == 0] > threshold_bayes) == 1) + np.sum((x_observed_means[state_of_nature == 1] > threshold_bayes) == 0)) / (MC)


    BAYES_RISK_SIMULATED = C_01 * PM_SIMULATED * (sum(state_of_nature == 1) / MC) + C_10 * PFA_SIMULATED * (np.sum(state_of_nature == 0) / MC)

    print(f"PFA_THEORY = {PFA_THEORY}, PM_THEORY = {PM_THEORY}, PE_THEORY = {PE_THEORY}\n")
    print(f"PFA_SIMULATED = {PFA_SIMULATED}, PM_SIMULATED = {PM_SIMULATED}, PE_SIMULATED = {PE_SIMULATED}\n")
    print(f"BAYES_RISK_THEORY = {BAYES_RISK_THEORY}\n")
    print(f"BAYES_RISK_SIMULATED = {BAYES_RISK_SIMULATED}\n")

    # Task 3
    plt.figure(figsize=(8,5))
    plt.hist(x_observed_means[state_of_nature == 0], bins=200, density=True,
             alpha=0.2, color='b', edgecolor='b', label='H_0 MC')
    plt.hist(x_observed_means[state_of_nature == 1], bins=200, density=True,
             alpha=0.2, color='r', edgecolor='r', label='H_1 MC')

    x_vals = np.arange(np.min(x_observed_means), np.max(x_observed_means), 0.01)
    H0_mean = 0
    H1_mean = A / np.sqrt(N)
    H0_std = np.sqrt(noise_variance / N)
    H1_std = np.sqrt(noise_variance / N)

    plt.plot(x_vals, norm.pdf(x_vals, H0_mean, H0_std), 'b', linewidth=2, label='H0 theory')
    plt.plot(x_vals, norm.pdf(x_vals, H1_mean, H1_std), 'r', linewidth=2, label='H1 theory')

    plt.axvline(threshold_bayes, color='g', linewidth=2, label='Threshold γ')
    plt.title('PDFs of sample mean x̄ under H0 and H1, MC and theoretical')
    plt.xlabel('x̄')
    plt.ylabel('PDF')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()
