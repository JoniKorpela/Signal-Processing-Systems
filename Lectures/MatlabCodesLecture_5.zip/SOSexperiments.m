% SOSexperiments    Experiments for the lecture 5
%
% << Syntax >>
%    SOSexperiments(index)
%
% << Arguments >>
%    index     11,12,13 - simulations for Experiment 1
%              21,22 - Exp 2, 3 - Exp 3

function SOSexperiments(index)
  
    matfile = sprintf('SOSexperiments_%d.mat',index);
    
    switch index
        case 11
            add_rp = 1;
            Bdelay = 8;
            p_roundFloorExp(Bdelay,add_rp,matfile,index);
        case 12
            add_rp = 1;
            Bdelay = 10;
            p_roundFloorExp(Bdelay,add_rp,matfile,index);
        case 13
            add_rp = 1;
            Bdelay = 12;
            p_roundFloorExp(Bdelay,add_rp,matfile,index);
        case 21
            p_multiplierExp('floor',matfile,index);
        case 22
            p_multiplierExp('round',matfile,index);
        case 3
            p_errorSpectrumExp(matfile,index);
    end
end

function p_roundFloorExp(Bdelay,add_rp,matfile,index)

    if exist(matfile,'file')
        load(matfile,'Fs','RMSEs','BIASes','RMSEs2','BIASes2'); 
        compute = 0; 
    else
        compute = 1;
    end

    [b,a] = ellip(2,0.5,20,0.4);
    if compute
        Fs = 0.05:0.025:0.45;
        Nf = length(Fs); 

        RMSEs = zeros(1,Nf); BIASes = zeros(1,Nf); 
        h = SOSsimulator(b,a,'L1t',[8,8,Bdelay],0,0,7,'floor','round');
        for n = 1:Nf, [RMSEs(n),BIASes(n)] = h.dspNoise('sine',Fs(n),add_rp); end

        RMSEs2 = zeros(1,Nf); BIASes2 = zeros(1,Nf); 
        h = SOSsimulator(b,a,'L1t',[8,8,Bdelay],0,0,7,'floor','floor');
        for n = 1:Nf, [RMSEs2(n),BIASes2(n)] = h.dspNoise('sine',Fs(n),add_rp); end

        save(matfile,'Fs','RMSEs','BIASes','RMSEs2','BIASes2');                        
    end

    hadc = saturatingADC(1,8);
    qstep = hadc.quantStep();
    sigma2A = qstep^2 / 12;
    yimp = filter(b,a,[1,zeros(1,499)]);
    sigma2 = sigma2A * sum(yimp.^2);

    signal_power = 0.5; % sine wave
    
    figure(100+2*index-1);
    h1 = plot(Fs,20*log10(RMSEs/sqrt(signal_power)),'bo-');
    hold on
    h2 = plot(Fs,20*log10(RMSEs2/sqrt(signal_power)),'r.-');

    h3 = plot([0,0.5],10*log10([sigma2,sigma2]/signal_power),'g-');
    hold off
    legend([h2,h1,h3],'Floor','Round','ADC noise');

    set(gca,'xlim',[0,0.5]);
    xlabel('Sine frequency / Fs')
    set(gca,'ylim',[-70,-30]);
    ylabel('DSP noise power / signal power [dB]')
    set(gca,'xgrid','on','ygrid','on');
    title(sprintf('Internal word length %d',Bdelay));
    
    figure(100+2*index);
    h1 = plot(Fs,BIASes ./ RMSEs,'bo-');
    hold on
    h2 = plot(Fs,BIASes2 ./ RMSEs2,'r.-');
    
    hold off
    legend([h2,h1],'Floor','Round');
    set(gca,'xlim',[0,0.5]);
    xlabel('Sine frequency / Fs')
    set(gca,'ylim',[-1.02,+1.02]);

    ylabel('BIAS / RMSE');
    set(gca,'xgrid','on','ygrid','on');
    title(sprintf('Internal word length %d',Bdelay));

end

function p_multiplierExp(rop,matfile,index)

    add_rp = 1;

    if exist(matfile,'file')
        load(matfile,'Fs','RMSEs0','RMSEs2','RMSEs4','RMSEs6','RMSEs8','RMSEs10'); 
        compute = 0; 
    else
        compute = 1;
    end

    [b,a] = ellip(2,0.5,20,0.4);
    if compute
        Fs = 0.05:0.025:0.45;
        Nf = length(Fs); 

        RMSEs0 = zeros(1,Nf);
        h = SOSsimulator(b,a,'L1t',[8,8,12],0,0,7,rop,'round');
        for n = 1:Nf, [RMSEs0(n)] = h.dspNoise('sine',Fs(n),add_rp); end
        RMSEs2 = zeros(1,Nf);
        h = SOSsimulator(b,a,'L1t',[8,8,12],2,0,7,rop,'round');
        for n = 1:Nf, [RMSEs2(n)] = h.dspNoise('sine',Fs(n),add_rp); end
        RMSEs4 = zeros(1,Nf);
        h = SOSsimulator(b,a,'L1t',[8,8,12],4,0,7,rop,'round');
        for n = 1:Nf, [RMSEs4(n)] = h.dspNoise('sine',Fs(n),add_rp); end
        RMSEs6 = zeros(1,Nf);
        h = SOSsimulator(b,a,'L1t',[8,8,12],6,0,7,rop,'round');
        for n = 1:Nf, [RMSEs6(n)] = h.dspNoise('sine',Fs(n),add_rp); end
        RMSEs8 = zeros(1,Nf);
        h = SOSsimulator(b,a,'L1t',[8,8,12],8,0,7,rop,'round');
        for n = 1:Nf, [RMSEs8(n)] = h.dspNoise('sine',Fs(n),add_rp); end
        RMSEs10 = zeros(1,Nf);
        h = SOSsimulator(b,a,'L1t',[8,8,12],10,0,7,rop,'round');
        for n = 1:Nf, [RMSEs10(n)] = h.dspNoise('sine',Fs(n),add_rp); end

        save(matfile,'Fs','RMSEs0','RMSEs2','RMSEs4','RMSEs6','RMSEs8','RMSEs10'); 
        
    end

    hadc = saturatingADC(1,8);
    qstep = hadc.quantStep();
    sigma2A = qstep^2 / 12;
    yimp = filter(b,a,[1,zeros(1,499)]);
    sigma2 = sigma2A * sum(yimp.^2);
    
    signal_power = 0.5; % sine wave

    figure(100+2*index-1);
    h0 = plot(Fs,20*log10(RMSEs0/sqrt(signal_power)),'bo-');
    hold on
    h2 = plot(Fs,20*log10(RMSEs2/sqrt(signal_power)),'r.-');
    h4 = plot(Fs,20*log10(RMSEs4/sqrt(signal_power)),'g.-');
    h6 = plot(Fs,20*log10(RMSEs6/sqrt(signal_power)),'m.-');
    h8 = plot(Fs,20*log10(RMSEs8/sqrt(signal_power)),'b.-');
    h10 = plot(Fs,20*log10(RMSEs10/sqrt(signal_power)),'k.-');
    hn = plot([0,0.5],10*log10([sigma2,sigma2]/signal_power),'g-');
    hold off    

    legend([h10,h8,h6,h4,h2,h0,hn],'r=10','r=8','r=6','r=4','r=2','r=0','ADC noise');
    set(gca,'xgrid','on','ygrid','on')
    set(gca,'xlim',[0,0.5],'ylim',[-70,-30])
    xlabel('Sine frequency / Fs')
    xlabel('Sine frequency / Fs')
    ylabel('DSP noise power / signal power [dB]')

end

function p_errorSpectrumExp(~,~)

    [b,a] = ellip(2,0.5,20,0.4);
    compute = 1;
    if compute
        h = SOSsimulator(b,a,'L1t',[8,8,12],6,0,7,'round','round');
        [~,~,diff1] = h.dspNoise('sine',0.4,0);
        [~,~,diff2] = h.dspNoise('sine',0.4,1);
        [~,~,diff3] = h.dspNoise('rand');
        figure(201);
        freqz(diff1);
        subplot(211);
        set(gca,'xlim',[-0.02,1.02])
        set(gca,'ylim',[-85,-15])
        figure(202);
        freqz(diff2);
        subplot(211);
        set(gca,'xlim',[-0.02,1.02])
        set(gca,'ylim',[-85,-15])
        figure(203);
        plot(diff1(1:100));
        set(gca,'ylim',[-0.0007,0.0007])
        figure(204);
        plot(diff2(1:100));
        set(gca,'ylim',[-0.0007,0.0007])

        figure(205);
        freqz(diff3);
        subplot(211);
        set(gca,'xlim',[-0.02,1.02])
        set(gca,'ylim',[-85,-15])
        
        figure(206);
        freqz(b,a);
        
    end

end
