% SOSsimulator   Simulate a fixed-point implementation of a second-order section (SOS)
%
% << Syntax >>
%    h = SOSsimulator(b,a,sp,[Bi,Bc,Bd],r,g,no,mround,qround)
%
% << Arguments >>
%    b         Numerator coefficients : [b(0),b(1),b(2)]
%    a         Denominator coefficients : [a(0),a(1),a(2)]
%    sp        Scaling factor : computation method ('L1t', 'L2t', 'Lif�) or a numeric value
%              - note: coefficients "b" are multiplied by this factor, input by 1/sp
%    Bi,Bc,Bd  Word length used for I/O, coefficients and delay memories
%              - multiplier outputs have word length Bc+Bd
%              - adder outputs have word length Bc+Bd+g
%    r         Number of bits discarded at multiplier output
%              - if r > 0, there will be round-off errors in multiplications
%    g         Number of accumulator guard bits (0-2)
%              - if necessary, can be used to prevent overflows in additions 
%    no        Number of fraction bits used for output
%    mround    Multiplier rounding method : 'floor', 'nearest', 'round', 'zero' or 'convergent'
%              - see fimath RoundingMethod for meaning
%              - note: 'floor' is same as truncation, which would be easiest to implement in HW
%    qround    Rounding method for word length reduction (Q) blocks
%    h         Structure of function handles
%
% << Description >>
%    The filter is implemented in the canonic direct form II.
%    Access functions are:
%    
%    h.info() 
%
%       shows information about the filter.
%
%    y = h.filter(x,N) 
%
%       simulates the filtering for input "x" (range -1..+1). Output length is "N".
%
%    y = h.filterNoDAC(x,N) 
%
%       simulates without final conversion to the output word length.
%
%    [bscaled,a,prescale] = h.qcoeff() 
%    [b,a] = h.quscoeff()
%
%       return information about the quantized coefficients. In the second function
%       output, b = prescaled * bscaled.
%
%    [RMSE,BIAS,diff] = h.dspNoise(testsig,...)
%
%       performs filtering using some test signals, and compares the result
%       to full-precision floating-point filtering. RMS error, BIAS and
%       difference are returned. Used to implement some experiments shown in
%       the lecture.
%
% << Examples >>
%    [b,a] = ellip(2,0.5,20,0.4);
%    hadc = saturatingADC(1,8);
%    hdsp = SOSsimulator(b,a,'L1t',[8,8,8],0,0,7,'floor','round')
%    x_in = 2*rand(1,100)-1; % Input to ADC
%    x = hadc.simulate(x_in,'float1'); % Output of ADC, scaled to (-1,+1) range
%    y = hdsp.filterNoDAC(x); % Fixed-point filtering, final quantization not done
%    yref = filter(b,a,x); % Reference: floating-point double precision filtering
%    plot(yref,'ro-'); hold on; plot(y,'b.-'); hold off
%    MSE = mean((y-yref).^2); 
%    title(sprintf('Noise level: %.1f dB',10*log10(MSE)));

function h = SOSsimulator(b,a,sp,B,r,g,no,mround,qround)

    p = p_prepare(b,a,sp,B,r,g,no,mround,qround);
    
    h.info = @x_info;
    h.filter = @x_filter;
    h.filterNoDAC = @x_filterNoDAC;
    h.qcoeff = @x_qcoeff;
    h.quscoeff = @x_quscoeff;
    h.dspNoise = @x_dspNoise;
    
    %% 
    function x_info
        p_printInfo(p);
    end

    %% Complete filtering
    function y = x_filter(x,N)
                
        if nargin == 2
            if length(x) < N
                x = [x,zeros(1,N-length(x))];
            else
                x = x(1:N);
            end                
        end
        x_in = fi(x,1,p.s_i(1),p.s_i(2)); % ADC quantization
        y_out = i_filterWithoutADA(x_in);
        y = i_applyQstep(y_out,p.s_o); % DAC
        y = double(y);
        
    end

    %% Filtering without final mapping to output word length
    function y = x_filterNoDAC(x,N)
                
        if nargin == 2
            if length(x) < N
                x = [x,zeros(1,N-length(x))];
            else
                x = x(1:N);
            end                
        end
        x_in = fi(x,1,p.s_i(1),p.s_i(2)); % ADC
        y_out = i_filterWithoutADA(x_in);
        y = double(y_out);

    end

    %% Private function: filtering without the first ADC and DAC related operations
    function y_out = i_filterWithoutADA(x_in)
        
        N = length(x_in);        
        y_out = zeros(1,N);
        
        P = fipref;
        P.LoggingMode = 'off';        
                
        % Initialization of memory
        w0 = fi(0,1,p.s_d(1),p.s_d(2));
        w1 = w0;
        
        for tick = 1:N
            w2 = w1;
            w1 = w0;
            
            % Feedback portion updates "w0"
            input = x_in(tick);
            inputd = fi(input,1,p.s_d(1),p.s_d(2));                         
            w0full = [p.isq, p.aq] * fi([inputd; w1; w2],p.Fa);
            w0 = i_applyQstep(w0full,p.s_d); 
                                  
            % Feedforward portion updates y
            ofull = p.bq * fi([w0; w1; w2],p.Fb);
            y_out(tick) = double(ofull);
        end        
    end

    %% Private function: Q blocks for word length reduction
    function out = i_applyQstep(in,sformat)
        out = removefimath(fi(in,1,sformat(1),sformat(2),'RoundingMethod',p.qround));        
    end

    %% Quantized coefficients
    function [bscaled,a,prescale] = x_qcoeff
        bscaled = double(p.bq);
        a = [1,-double(p.aq)];
        prescale = double(p.isq);        
    end
 
    %% Quantized coefficients, without pre-scaling 
    function [b,a] = x_quscoeff
        [bscaled,a,prescale] = x_qcoeff();
        b = prescale * bscaled;        
    end

    %% Function used to implement experiments
    function [RMSE,BIAS,diff] = x_dspNoise(testsig,varargin)
        switch testsig
            case 'sine'
                freq = varargin{1};
                add_rp = varargin{2};
                if add_rp
                    rphaseRange = 0.001;
                else
                    rphaseRange = 0;
                end
                assert((freq >= 0.01) && (freq <= 0.49));
                rseed = ceil(10000*freq);
                rstream = RandStream('mt19937ar','Seed',rseed);
                N = max(round(5 * 2 * pi / freq),3000);
                rr = rphaseRange * rand(rstream,1,N);
                n = 0:(N-1);
                x_in = sin(2*pi*freq*n + rr);
                signaltxt = sprintf('Sine F=%.3f',freq);
            case 'rand'
                rstream = RandStream('mt19937ar','Seed',1);                
                N = 3000;
                x_in = 2*rand(rstream,1,N)-1;
                signaltxt = sprintf('Random (-1,1)');
            otherwise
                error('bad testsig argument');
        end
        y_out = i_filterWithoutADA(x_in);
        y_flp = filter(b,a,x_in);
        diff = y_out-y_flp;
        MSE = mean(diff.^2);
        BIAS = mean(diff);
        RMSE = sqrt(MSE);
        MSEdB = 10 * log10(MSE);
        fprintf('%s DSP noise: RMSE %.12f %.3f dB BIAS %.12f\n',signaltxt,RMSE,MSEdB,BIAS);
    end


end

%% Setting up the fixed-point filter

function p = p_prepare(b,a,sp,B,r,g,no,mround,qround)

    assert(numel(b) == 3);
    assert(numel(a) == 3);
    if a(1) ~= 1
        % Force it         
        mplier = 1 / a(1);
        b = mplier * b;
        a = mplier * a;
        fprintf('Forcing a0 == 1 by scaling coefficients\n');
    end    
    a1 = a(2); a2 = a(3);
    p.b = b;
    p.a1 = a1;
    p.a2 = a2;

    p.r = r;
    p.g = g;
    
    Bio = B(1); Bc = B(2); Bd = B(3);
    assert(Bd >= Bio);
    p.B = B;
    
    % Feedback portion: quantization of coefficients (p.aq)
    nca = p_bestPrecisionForCoeff([a1,a2],Bc);
    p.aq = fi([a1,a2],1,Bc,nca);    
    
    % Scaling factor
    % Using quantized coefficients to compute it
    aq = [1,double(p.aq)];
    if ischar(sp)
        switch sp
            % Typical choices
            case 'L1t'    % L1 norm in time domain               
                f = impz(1,aq);
                s = norm(f,1);
            case 'L2t'    % L2 norm in time domain, from impulse response
                f = impz(1,aq);
                s = norm(f,2);
            case 'L2t-cf' % L2 norm in time domain, closed form evaluation
                aq1 = aq(2); aq2 = aq(3);
                s = sqrt(1 / (1 - aq2^2 - aq1^2*(1-aq2)/(1+aq2)));
            case 'Lif'    % Linf norm in frequency domain
                H = freqz(1,aq);
                s = max(abs(H));
                
            % Other choices            
            case 'Lit'    % Linf norm in time domain
                f = impz(1,aq);
                s = max(abs(f));
            case 'L2f'    % L2 norm in frequency domain, corresponds to 'L2t'
                H = freqz(1,aq);
                s = norm(abs(H),2)/sqrt(numel(H));
            case 'L1f'    % L1 norm in frequency domain
                H = freqz(1,aq);
                s = norm(abs(H),1)/numel(H);
            otherwise
                error('bad scaling argument (#5)');
        end
    else
        % User's choice
        s = sp;
    end
    p.s = s;

    % Quantized pre-scaling factor (p.isq)    
    isq = fi(1/s,1,Bc,nca,'RoundingMethod','Floor');
    p.isq = fi(0,1,Bc,nca);
    p.isq = isq;
    
    % Pre-scaling compensation insert to feedforward coefficients
    p.b_scaled = (1/double(p.isq)) * b;
        
    % Quantizing scaled feedforward coefficients
    ncb = p_bestPrecisionForCoeff(p.b_scaled,Bc);
    p.bq = fi(p.b_scaled,1,Bc,ncb);

    % Formats
    p.s_i = [Bio,Bio-1];
    p.s_o = [Bio,no];
    p.s_d = [Bd,Bd-1];
    p.s_m_b = [Bc+Bd-r,ncb+Bd-1-r];
    p.s_a_b = [Bc+Bd-r+g,ncb+Bd-1-r];
    p.s_m_a = [Bc+Bd-r,nca+Bd-1-r];
    p.s_a_a = [Bc+Bd+g-r,nca+Bd-1-r];
    p.c_b = [Bc,ncb];
    p.c_a = [Bc,nca];
    

    p.Fb = p_fimath(p.s_m_b,p.s_a_b,mround);
    p.Fa = p_fimath(p.s_m_a,p.s_a_a,mround);

    p.bq = fi(p.bq,p.Fb);
    p.aq = fi(-p.aq,p.Fa); % Negation here!
    p.isq = fi(p.isq,p.Fa);
    
    xx = fi(0,1,'RoundMode',qround); % Generate error if "qround" not appropriate
    p.qround = xx.RoundMode;
    
    p_printInfo(p);
    
end

%% Printing information about the filter configuration

function p_printInfo(p)

    fprintf('Floating-point filter coefficients\n');
    fprintf(' - feedforward: b0=%.12f b1=%.12f b2=%.12f\n',p.b);
    fprintf(' - feedback: a1=%.12f a2=%.12f\n',p.a1,p.a2);
    fprintf('Word lengths: I/O %d coefficients %d delay memory %d\n',p.B);
    fprintf('Scaling factor: %.12f\n',p.s);
    fprintf(' - scaled feedforward: b0=%.12f b1=%.12f b2=%.12f\n',p.b_scaled);
    fprintf('Quantized coefficients\n');
    fprintf(' - pre-scaling: 1/s=%.12f\n',double(p.isq));
    fprintf(' - scaled feedforward: b0=%.12f b1=%.12f b2=%.12f\n',double(p.bq));
    fprintf(' - feedback: a1=%.12f a2=%.12f\n',-double(p.aq));

    fprintf('Fixed-point formats\n');
    fprintf(' - input : s%d.%d\n',p.s_i);
    fprintf(' - output: s%d.%d (rounding mode ''%s'')\n',p.s_o,p.qround);
    fprintf(' - delay : s%d.%d (rounding mode ''%s'')\n',p.s_d,p.qround);
    fprintf(' - coefficients\n   - scaled b: s%d.%d\n   - a: s%d.%d\n',p.c_b,p.c_a);
    if p.r > 0, txt = sprintf('rounding mode ''%s'', %d bits',p.Fb.RoundMode,p.r); else, txt = sprintf('no rounding'); end 
    fprintf(' - multiplier outputs (%s)\n   - b: s%d.%d\n   - a: s%d.%d\n',txt,p.s_m_b,p.s_m_a);
    fprintf(' - accumulator\n   - b: s%d.%d\n   - a: s%d.%d\n',p.s_a_b,p.s_a_a);

end

%% Compute fraction length for best precision representation

function nc = p_bestPrecisionForCoeff(coeff,Bc)

    nc = Bc - floor(log2(max(abs(coeff)))) - 2;
    
end

%% Constructing fimath objects

function F = p_fimath(s_m,s_a,mround)

    F = fimath('ProductMode','SpecifyPrecision',...
        'ProductWordLength',s_m(1),'ProductFractionLength',s_m(2),...
        'RoundingMethod',mround,...
        'SumMode','SpecifyPrecision',...
        'SumWordLength',s_a(1),'SumFractionLength',s_a(2));

end

%%
