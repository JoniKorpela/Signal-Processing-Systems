% << Syntax >>
%    crestFactorPlot(x,Ps,B)
%
% << Arguments >>
%    x     Input signal samples
%    Ps    Peak absolute value of ADC range
%    B     ADC output word length
%
% << Description >>
%    Simulates saturating A/D conversion for the input signal "x"
%    for the specified ADC ranges and word length. Then, plots the 
%    clipping and quantization noises with respect to the crest factor.
%    In this way, illustrates the trade-off between clipping and
%    quantization noises.
%
% << See also >>
%    saturatingADC
%
% << Examples >>
%    % Gaussian signal with variance 1
%    x = randn(1,1000000);
%    Ps = 1.0:0.5:4.5; % 
%    B = 10;
%    crestFactorPlot(x,Ps,B)
%
%    % Sine wave
%    x = sin(2*pi*(1:10000)/10000);
%    Ps = 0.1:0.1:1.0;
%    B = 6;
%    crestFactorPlot(x,Ps,B)

function crestFactorPlot(x,Ps,B)

    value_for_dbInf = -180;
    
    Ss = zeros(size(Ps));
    Ncs = zeros(size(Ps));
    Nqs = zeros(size(Ps));
    K = numel(Ps);
    for k = 1:K
        P = Ps(k);
        h = saturatingADC(P,B);
        [Ss(k),Ncs(k),Nqs(k)] = h.powers(x);        
    end
    normNcs = zeros(size(Ncs));
    Ic = Ncs ~= 0;
    normNcs(Ic) = 10 * log10(Ncs(Ic) ./ Ss(Ic));
    normNcs(~Ic) = value_for_dbInf;
    normNqs = zeros(size(Nqs));
    Iq = Nqs ~= 0;
    normNqs(Iq) = 10 * log10(Nqs(Iq) ./ Ss(Iq));
    normNqs(~Ic) = value_for_dbInf;
    
    Ns = Ncs + Nqs;
    normNs = zeros(size(Ns));
    I = Ns ~= 0;
    normNs(I) = 10 * log10(Ns(I) ./ Ss(I));
    normNs(~I) = value_for_dbInf;
    
    rms = sqrt(mean(x(:).^2));
    PRR = (1/rms) * Ps;
    CFs = 20 * log10(PRR); 

    h1 = plot(CFs,normNcs,'bo-');
    hold on
    h2 = plot(CFs,normNqs,'rs-');
    h3 = plot(CFs,normNs,'g.--');
    hold off
    xlabel('Crest factor [dB]');
    ylabel('Noise power / Signal power [dB]');
    legend([h1,h2,h3],'Clipping','Quantization','Sum');
    set(gca,'xgrid','on','ygrid','on');
    title(sprintf('Word length: %d Peak range: %.3f-%.3f',B,min(Ps),max(Ps)));
    
end

