% SATURATINGADC Tool for simulating saturating A/D conversions
% 
% << Syntax >>
%    h = saturatingADC(P,B)
%
% << Arguments >>
%    P   Maximum absolute input value
%    B   Output word length
%    h   Structure of access functions (see description below)
%
% << Description >>
%    Access functions are:
%
%    Input parameters can be queried using 
%
%    P = h.inputPeak()
%    B = h.wordLength()
%
%    The quantization step size (calculated from P and B) is returned by
%
%    delta = h.quantStep()
%
%    ADC operation can be simulated for the input signal "x" using
%
%    [Y,clipped] = h.simulate(x,'int')
%    [yP,clipped] = h.simulate(x,'floatP');
%    [y1,clipped] = h.simulate(x,'float1');
%
%    where "Y" is the integer output and "clipped" flags those input values
%    that have resulted in saturation. "yP" is a floating point value in
%    the range (-P,P). "y1" is a floating point value in the range (-1,1).
%    Default mode is 'int'.
%
%    [S,Nclip,Nquant] = h.powers(x)
%
%    performs simulation for "x" and computes powers.

function h = saturatingADC(P,B)

    h.inputPeak = @x_inputPeak;
    h.wordLength = @x_wordLength;
    h.quantStep = @x_quantStep;
    h.simulate = @x_simulate;
    h.powers = @x_powers;
        
    function v = x_inputPeak
        v = P;
    end

    function v = x_wordLength
        v = B;
    end

    function delta = x_quantStep
        delta = P / 2^(B-1);
    end

    function [Y,clipped] = x_simulate(x,mode)
        if nargin < 2, mode = 'int'; end
        delta = x_quantStep();
        Y = round((1/delta) * x);
        T_lo = -2^(B-1);
        clip_lo = Y < T_lo;
        Y(clip_lo) = T_lo;
        T_hi = 2^(B-1)-1;
        clip_hi = Y > T_hi;
        Y(clip_hi) = T_hi;                
        clipped = clip_lo | clip_hi;
        switch mode
            case 'int'
                % Return integer
            case 'floatP'
                Y = (P / 2^(B-1)) * Y;
            case 'float1'
                Y = (1 / 2^(B-1)) * Y;
            otherwise
                error('bad mode (arg#2)');
        end
    end

    function [S,Nclip,Nquant] = x_powers(x)
        x = x(:);
        [Y,clipped] = x_simulate(x);
        S = mean(x.^2);
        delta = x_quantStep();
        y = delta * Y;
        Nsamples = numel(x);
        Nclip = (1/Nsamples) * sum((y(clipped) - x(clipped)).^2);
        Nquant = (1/Nsamples) * sum((y(~clipped) - x(~clipped)).^2);
    end

end
